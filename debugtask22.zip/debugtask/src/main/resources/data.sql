INSERT INTO USER (email, password) VALUES ('test@example.com', '$2a$10$Dow1xra8KMm3u82YHcbEKOm5JUbEXXwqReKvB0C46Ct1iwPeF9asG'); -- password123
